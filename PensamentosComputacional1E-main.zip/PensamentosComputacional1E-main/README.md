# PensamentosComputacional 1E
Repositorio criado para postagem de trabalhos da disciplina de pensamento computacionalnto

*Maicon N°42*

## _**colorir**_

faltará tinta

No dia que o céu for livre

Pra todos serem o que são

Cobertos pelo sol, sem nenhum tipo de opressão

Faltará nomes

Pra descrever o mundo sem as misérias

O que sentimos, o que nos tornamos

O novo ser sem medo de viver

Faltará a falta que nos entristece

Que hoje enche o peito de vazio e fumaça

Não faltará amor, não faltará sonhos

O novo mundo se abrirá para o futuro

Onde o presente dominará o passado

E nossos corações enfim serão salvos

professor@LiziBugalski

 ![texto](https://i.pinimg.com/564x/98/c3/2b/98c32bdd201c23df41da4e4499eec594.jpg)
